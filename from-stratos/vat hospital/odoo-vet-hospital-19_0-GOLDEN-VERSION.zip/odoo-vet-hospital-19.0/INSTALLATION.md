# Installation Guide - Veterinary Hospital for Odoo 19

## 📋 Prerequisites Checklist

Before installing, verify you have:

```
✓ Odoo 19 Community Edition (running and accessible)
✓ Database access (with admin privileges)
✓ Linux/Windows system with appropriate permissions
✓ Python 3.8+ installed
✓ PostgreSQL 12+ installed
✓ Internet connection (for Merck integration)
✓ Backup of current Odoo installation
✓ Backup of database
```

**Important**: Always backup your database before installing new modules!

---

## 🚀 Installation Steps (5 Minutes)

### Step 1: Extract the Package

```bash
# Option A: Using command line
unzip odoo-vet-hospital-19.0.zip
cd odoo-vet-hospital-19.0

# Option B: Using file manager
# Right-click odoo-vet-hospital-19.0.zip → Extract All
# Navigate to extracted folder
```

### Step 2: Copy Modules to Odoo

```bash
# Find your Odoo addons directory
# Common paths:
# /opt/odoo/addons/
# /var/lib/odoo/addons/
# /home/odoo/addons/
# C:\Program Files\Odoo\addons\  (Windows)

# Copy modules
cp -r vet_hospital /path/to/odoo/addons/
cp -r vet_hospital_merck /path/to/odoo/addons/

# On Windows (using PowerShell or Command Prompt):
# Copy-Item -Path "vet_hospital" -Destination "C:\path\to\odoo\addons\" -Recurse
# Copy-Item -Path "vet_hospital_merck" -Destination "C:\path\to\odoo\addons\" -Recurse
```

**Note**: Make sure paths are correct for your system.

### Step 3: Set File Permissions (Linux Only)

```bash
# Change ownership to Odoo user
sudo chown -R odoo:odoo /path/to/odoo/addons/vet_hospital
sudo chown -R odoo:odoo /path/to/odoo/addons/vet_hospital_merck

# Set appropriate permissions
sudo chmod -R 755 /path/to/odoo/addons/vet_hospital
sudo chmod -R 755 /path/to/odoo/addons/vet_hospital_merck
```

### Step 4: Restart Odoo Service

```bash
# Using systemd (Ubuntu/Debian)
sudo systemctl restart odoo

# Using service command
sudo service odoo restart

# On Windows:
# 1. Open Services (services.msc)
# 2. Find Odoo service
# 3. Right-click → Restart

# Manual restart:
# 1. Stop the Odoo process
# 2. Wait 10 seconds
# 3. Start Odoo again
```

**Wait 30-60 seconds for Odoo to fully restart**

### Step 5: Update Apps List in Odoo

1. **Log in to Odoo** as Administrator
2. **Go to**: Settings → Apps (or Apps → Apps)
3. **Click**: "Update Apps List" button
4. **Wait** for update to complete (may take 1-2 minutes)

```
You should see message: "Modules updated successfully"
```

### Step 6: Install Core Module

1. **Go to**: Settings → Apps
2. **Search**: "Veterinary Hospital Management" or "vet_hospital"
3. **Click** on the module card
4. **Click**: "Install" button
5. **Wait** for installation (1-2 minutes)

**Status should change to "Installed" (green)**

### Step 7: Install Merck Integration (Optional)

1. **Go to**: Settings → Apps
2. **Search**: "Merck" or "Veterinary Hospital - Merck"
3. **Click** on the module card
4. **Click**: "Install" button
5. **Wait** for installation (1 minute)

**Status should change to "Installed" (green)**

### Step 8: Verify Installation

1. **Close** Settings tab
2. **Refresh** page (F5 or Ctrl+R)
3. **Look** for new menu items in left sidebar:
   - You should see: **"Veterinary Hospital"** menu
   - (Optional) You may see: **"Merck Vet Manual"** menu
4. **Click** Veterinary Hospital menu
5. **Verify** sub-items appear:
   - Dashboard
   - Patient Management
   - Schedule & Appointments
   - Medical Records
   - Prescriptions & Medications
   - Billing & Invoices
   - Reports
   - Configuration

**If all menu items appear → Installation successful! ✅**

---

## 🔍 Troubleshooting Installation

### Issue 1: Module Not Appearing in Apps List

**Solutions:**
1. Did you update apps list? (Settings → Apps → Update Apps List)
2. Are modules in correct directory? (Check /odoo/addons/vet_hospital exists)
3. Is Odoo running? (Check service status)
4. Are there permission issues? (Check file ownership)

**Fix:**
```bash
# Force update apps list
cd /opt/odoo  # or your Odoo directory
./odoo-bin -d your_database -u base --stop-after-init

# Or restart and update in UI
sudo systemctl restart odoo
# Then Settings → Apps → Update Apps List
```

### Issue 2: Installation Fails with Error

**Common errors:**
- "Module depends on uninstalled module" → Install dependencies first
- "Database error" → Check PostgreSQL is running
- "Permission denied" → Check file permissions
- "Module not found" → Check module path

**Fix:**
1. Check Odoo logs: `/var/log/odoo/odoo-server.log`
2. Verify PostgreSQL running: `sudo systemctl status postgresql`
3. Check permissions: `sudo chown -R odoo:odoo /path/to/addons`
4. Restart and try again

### Issue 3: Installation Hangs

**Solutions:**
1. Wait 5-10 minutes (large modules take time)
2. Check logs for errors
3. Restart Odoo and try again
4. Increase PostgreSQL timeout

**Fix:**
```bash
# Check Odoo is not frozen
ps aux | grep odoo

# Check PostgreSQL
sudo systemctl status postgresql

# If frozen, restart
sudo systemctl restart odoo
```

### Issue 4: Module Installed but Menu Not Appearing

**Solutions:**
1. Close and reopen browser tab
2. Hard refresh page (Ctrl+Shift+R or Cmd+Shift+R)
3. Clear browser cache
4. Use incognito/private window

**Fix:**
```bash
# Browser cache clear (different browsers):
# Chrome: Ctrl+Shift+Delete
# Firefox: Ctrl+Shift+Delete
# Safari: Cmd+Shift+Delete
# Edge: Ctrl+Shift+Delete
```

### Issue 5: "Veterinary Hospital" Menu But No Sub-Items

**Solutions:**
1. Refresh page (F5)
2. Clear cache (Ctrl+Shift+R)
3. Check module loaded correctly

**Fix:**
```bash
# Verify installation in database
# Go to: Settings → Apps → Installed
# Search "Veterinary"
# Should show both modules as "Installed"
```

---

## ⚙️ Post-Installation Configuration

After successful installation, configure the system:

### 1. Create Veterinarians

```
Path: Contacts → New
Steps:
1. Enter Name: "Dr. Smith"
2. Scroll down → Check "Is Veterinarian"
3. Fill in:
   - License Number: "VET12345"
   - Specialization: "General Practice"
4. Set Working Hours:
   - Monday-Friday: 08:00-17:00
   - Saturday: 09:00-12:00
   - Sunday: (empty)
5. Save
```

**Repeat for each veterinarian**

### 2. Create Pet Owners

```
Path: Contacts → New
Steps:
1. Enter Name: "John Doe"
2. Scroll down → Check "Is Pet Owner"
3. Fill in:
   - Email: owner@example.com
   - Phone: (555) 123-4567
   - Emergency Contact: "Jane Doe"
   - Emergency Phone: (555) 123-4568
   - Preferred Veterinarian: "Dr. Smith"
   - Notification Method: "Email"
4. Save
```

**Repeat for each owner**

### 3. Register First Patient

```
Path: Veterinary Hospital → Patients → Create
Steps:
1. Pet Name: "Max"
2. Species: "Canine"
3. Breed: "Golden Retriever"
4. Owner: "John Doe"
5. Date of Birth: "2020-01-15"
6. Gender: "Male"
7. Weight: "32 kg"
8. (Optional) Add photo
9. Save
```

### 4. Configure Email (For Appointment Reminders)

```
Path: Settings → Technical → Outgoing Mail Servers
Steps:
1. Click "Create"
2. Fill in your mail server details:
   - Name: "Gmail" (or your provider)
   - SMTP Server: "smtp.gmail.com"
   - SMTP Port: "587"
   - Username: "your-email@gmail.com"
   - Password: "your-password"
   - TLS Required: Yes
3. Click "Test Connection"
4. Save
```

**Note**: Gmail requires "App Password" (not account password)

### 5. Schedule First Appointment

```
Path: Veterinary Hospital → Appointments → Create
Steps:
1. Date & Time: Pick future date/time
2. Appointment Type: "Wellness Check"
3. Patient: "Max"
4. Veterinarian: "Dr. Smith"
5. Reason: "Annual checkup"
6. Click "Confirm" (to send email reminder)
7. Save
```

### 6. Create Medical Record

```
Path: Veterinary Hospital → Appointments → Select appointment
Steps:
1. Click "Create Medical Record" button
2. Fill SOAP sections:
   - S (Subjective): "Owner reports good health"
   - O (Objective): "Normal physical exam"
   - A (Assessment): "Healthy dog"
   - P (Plan): "Continue current diet"
3. Record Vital Signs:
   - Temperature: 38.5°C
   - Heart Rate: 75 bpm
   - Respiration: 18 bpm
   - Weight: 32 kg
4. Click "Complete"
5. Click "Create Invoice"
6. Save
```

---

## 🧪 Testing Installation

After configuration, test the system:

### Test 1: Navigate Menus
- [ ] Patients menu accessible
- [ ] Appointments menu accessible
- [ ] Medical Records menu accessible
- [ ] Vital Signs menu accessible
- [ ] Prescriptions menu accessible
- [ ] Billing menu accessible

### Test 2: Create Records
- [ ] Create new patient
- [ ] Create new appointment
- [ ] Create new medical record
- [ ] Record vital signs
- [ ] Add prescription
- [ ] Generate invoice

### Test 3: Search & Filter
- [ ] Search patients by name
- [ ] Filter appointments by date
- [ ] Search medical records by diagnosis
- [ ] Filter vital signs by abnormality

### Test 4: Reports (Optional)
- [ ] Generate medical record report
- [ ] Generate appointment report
- [ ] Generate billing report

### Test 5: Merck Integration (Optional)
- [ ] Open medical record with diagnosis
- [ ] Click "Merck: Diagnosis" button
- [ ] Verify Merck opens in new tab
- [ ] Verify search term is pre-filled

**If all tests pass → System is ready for use! ✅**

---

## 📊 Verification Checklist

After installation, verify:

### Database
- [ ] Database connection working
- [ ] PostgreSQL running
- [ ] Odoo can read/write database

### Modules
- [ ] vet_hospital installed (green "Installed" status)
- [ ] vet_hospital_merck installed (green "Installed" status)
- [ ] No error messages in logs

### Interface
- [ ] "Veterinary Hospital" menu visible
- [ ] All sub-menus accessible
- [ ] Forms load without errors
- [ ] Views display correctly

### Data
- [ ] Pre-loaded species visible (6)
- [ ] Pre-loaded breeds visible (12)
- [ ] Pre-loaded appointment types visible (7)
- [ ] Can create new records

### Functionality
- [ ] Can create patients
- [ ] Can schedule appointments
- [ ] Can create medical records
- [ ] Can record vital signs
- [ ] Can add prescriptions
- [ ] Can generate invoices
- [ ] Can generate reports

### (Optional) Merck
- [ ] Merck buttons visible in forms
- [ ] Buttons open Merck correctly
- [ ] Searches work as expected

---

## 🔒 Security Configuration

### Set User Permissions

```
Path: Settings → Users & Companies → Users
Steps:
1. Select user
2. Group(s): Add appropriate group:
   - Veterinary Hospital User (default)
   - System Administrator (full access)
3. Save
```

### Backup Configuration

```bash
# Daily backup script (Linux)
# Add to crontab: crontab -e

# Backup database at 2 AM daily
0 2 * * * pg_dump -U postgres your_database | gzip > /backups/odoo_$(date +\%Y\%m\%d).sql.gz

# Keep last 30 days
find /backups -name "odoo_*.sql.gz" -mtime +30 -delete
```

---

## 📚 Documentation Access

### Module Documentation

After installation, read:

1. **In Odoo UI**: 
   - No built-in docs (external files only)

2. **In Installation Package**:
   - `README.md` - Overview
   - `vet_hospital/README.md` - Complete guide (60 pages)
   - `vet_hospital/MODULE_STRUCTURE.md` - Technical details (30 pages)
   - `vet_hospital_merck/README.md` - Merck integration (60 pages)

### Online Resources

- **Odoo Documentation**: https://www.odoo.com/documentation/19.0/
- **Merck Vet Manual**: https://www.merckvetmanual.com/
- **This Module GitHub**: (if published)

---

## 🐛 Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| Module not appearing | Wrong directory | Check path in step 2 |
| Installation error | Missing dependency | Install base module first |
| Menu not showing | Browser cache | Ctrl+Shift+R to refresh |
| Buttons not appearing | Module not installed | Reinstall Merck module |
| Email not sending | Mail server not configured | Configure in Settings |
| Appointment conflict error | Double-booking | Choose different time slot |

---

## ✅ Verification Script (Linux)

```bash
#!/bin/bash
# Verify Odoo installation

echo "Checking Odoo installation..."

# Check Odoo running
echo -n "Odoo service running: "
systemctl is-active odoo && echo "✓" || echo "✗"

# Check PostgreSQL
echo -n "PostgreSQL running: "
systemctl is-active postgresql && echo "✓" || echo "✗"

# Check modules exist
echo -n "vet_hospital module exists: "
[ -d "/opt/odoo/addons/vet_hospital" ] && echo "✓" || echo "✗"

echo -n "vet_hospital_merck module exists: "
[ -d "/opt/odoo/addons/vet_hospital_merck" ] && echo "✓" || echo "✗"

# Check permissions
echo -n "vet_hospital readable: "
[ -r "/opt/odoo/addons/vet_hospital" ] && echo "✓" || echo "✗"

echo "Verification complete!"
```

---

## 🆘 Need Help?

### Troubleshooting Steps

1. **Check Odoo Logs**
   ```bash
   sudo tail -f /var/log/odoo/odoo-server.log
   ```

2. **Check PostgreSQL**
   ```bash
   sudo -u postgres psql -d your_database
   ```

3. **Restart Odoo**
   ```bash
   sudo systemctl restart odoo
   ```

4. **Check File Permissions**
   ```bash
   sudo chown -R odoo:odoo /opt/odoo/addons/vet_hospital
   ```

5. **Reinstall Module**
   - Settings → Apps → Installed
   - Search module
   - Click menu (⋮) → Upgrade or Uninstall & Reinstall

### Getting Support

1. Read documentation files
2. Check troubleshooting section above
3. Review Odoo logs
4. Check module README files
5. Contact your administrator

---

## 📝 Installation Log

Keep track of your installation:

```
Installation Date: _______________
Odoo Version: 19.0
Database Name: _______________
Admin User: _______________
Veterinarians Created: _______________
Pet Owners Created: _______________
Test Appointment Created: Yes / No
Email Configured: Yes / No
Installation Status: ✓ Complete / ✗ Failed

Notes:
_________________________________________________
_________________________________________________
```

---

## ✨ Next Steps

After successful installation:

1. **Read**: vet_hospital/README.md (60 pages)
2. **Configure**: Create veterinarians, owners, basic data
3. **Test**: Create sample patient and appointment
4. **Train**: Show team how to use system
5. **Deploy**: Start using in production

---

## 📞 Support Resources

- **Odoo Support**: https://www.odoo.com/support
- **Odoo Community**: https://github.com/OCA/
- **Module Docs**: See README files in package
- **Email Support**: (if applicable)

---

**Version**: 19.0.1.0.0  
**Created**: June 2026  
**Last Updated**: June 2026  

✅ **Installation Guide Complete!**

Happy Veterinary Practice! 🐾

---

For detailed information on features and usage, see README.md or FEATURES.md
